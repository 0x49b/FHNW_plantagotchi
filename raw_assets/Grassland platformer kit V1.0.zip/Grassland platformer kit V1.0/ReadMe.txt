                                                   
 __    _____ _____ _____ _____ _____   _____ _____ 
|  |  |     |     |_   _|     |   __| |     |     |
|  |__|  |  |  |  | | | | | | |   __|_|-   -|  |  |
|_____|_____|_____| |_| |_|_|_|_____|_|_____|_____|
                                                   

Hi there!

I would like to thank you for purchasing my kit and 
hope that you will enjoy using it to create awesome games!

--------------

This is my first Kit published to Itch.io and I will 
be creating more kits in the near future!

--------------

If you want to stay up to date then give me a
a follow on Twitter:

https://twitter.com/LootMeIO

And join the LootMe.io Discord server for any questions and support:

https://discord.me/lootme

